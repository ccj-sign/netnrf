﻿namespace Netnr.Domain
{
    public partial class SysMenu
    {
        public string SmId { get; set; }
        public string SmPid { get; set; }
        public string SmName { get; set; }
        public string SmUrl { get; set; }
        public int? SmOrder { get; set; }
        public string SmIcon { get; set; }
        public int? SmStatus { get; set; }
        public int? SmGroup { get; set; }
    }
}
