﻿namespace Netnr.Domain
{
    public partial class SysButton
    {
        public string SbId { get; set; }
        public string SbPid { get; set; }
        public string SbBtnText { get; set; }
        public string SbBtnId { get; set; }
        public string SbBtnClass { get; set; }
        public string SbBtnIcon { get; set; }
        public int? SbBtnOrder { get; set; }
        public int? SbStatus { get; set; }
        public string SbDescribe { get; set; }
        public int? SbBtnGroup { get; set; }
        public int? SbBtnHide { get; set; }
    }
}
