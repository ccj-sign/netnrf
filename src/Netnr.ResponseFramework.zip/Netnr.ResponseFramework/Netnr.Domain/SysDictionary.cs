﻿namespace Netnr.Domain
{
    public partial class SysDictionary
    {
        public string SdId { get; set; }
        public string SdPid { get; set; }
        public string SdType { get; set; }
        public string SdKey { get; set; }
        public string SdValue { get; set; }
        public int? SdOrder { get; set; }
        public int? SdStatus { get; set; }
        public string SdRemark { get; set; }
        public string SdAttribute1 { get; set; }
        public string SdAttribute2 { get; set; }
        public string SdAttribute3 { get; set; }
    }
}
