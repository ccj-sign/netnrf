﻿namespace Netnr.Func.ViewModel
{
    /// <summary>
    /// 键值对，下拉列表等
    /// </summary>
    public class ValueTextVM
    {
        /// <summary>
        /// 值
        /// </summary>
        public string value { get; set; }
        /// <summary>
        /// 文本
        /// </summary>
        public string text { get; set; }
    }
}