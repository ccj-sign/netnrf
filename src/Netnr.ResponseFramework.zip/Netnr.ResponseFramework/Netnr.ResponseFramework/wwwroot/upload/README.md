﻿- 静态资源根目录
- 用户上传的文档
- 建议创建子目录，如doc、temp、template等