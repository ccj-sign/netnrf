﻿- init.js：系统首页、菜单导航、选项卡、皮肤、字体设置等功能
- z.js：核心脚本封装

---
+ 页面脚本存放目录，存放规则:{controller}/{action}.js
+ 如：/Home/Index 页面对应的存放脚本为：/home/index.js
+ 统一小写

---
+ 如有域，请在 wwwroot/areas/js/ 创建