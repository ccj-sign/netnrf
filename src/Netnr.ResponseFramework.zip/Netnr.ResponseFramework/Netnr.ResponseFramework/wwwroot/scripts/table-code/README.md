﻿参数说明：

@TableName@ 表名
@TableTitle@ 标题名称
@PrimaryKey@ 主键列名


附：

生成代码仅针对单表简单的增删改查