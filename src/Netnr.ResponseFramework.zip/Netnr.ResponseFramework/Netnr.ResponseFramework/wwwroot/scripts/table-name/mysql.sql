﻿-- 查询数据库所有表名

SHOW TABLES FROM @DataBaseName