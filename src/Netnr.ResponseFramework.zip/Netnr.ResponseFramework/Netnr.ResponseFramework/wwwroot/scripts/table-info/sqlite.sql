﻿-- 查询系统表生成表字典

PRAGMA table_info('@TableName');