﻿- 数据库表设计
- 可从数据库逆向生成PowerDesigner